#!/bin/sh
BITRATE=`expr $2 \\* 1000`

ifconfig $1 down
canconfig $1 bitrate $BITRATE
canconfig $1 ctrlmode loopback off
canconfig $1 start




