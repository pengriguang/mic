#!/bin/bash
if [ -d "/userapp/mic7001_app" ]; then
	echo "check the version and enforce flag"
	
	if [ ! -f "/userapp/mic7001_app/version.dat" ]; then
		echo "no version file in mic7001_app, do not need update, remove directory enforce_new next"
		rm -rf /userapp/mic7001_app
	else
		while read line; do
			name=`echo $line|awk -F '=' '{print $1}'`
			value=`echo $line|awk -F '=' '{print $2}'`
			case $name in
			"version")
				version_new=$value
				;;
			"enforce")
				enforce_new=$value
				;;
			*)
				;;
		esac
		done < /userapp/mic7001_app/version.dat
		
		#echo $version_new
		#echo $enforce_new
		
		if [ ! -f "/userapp/PlcLogic/version.dat" ]; then
			echo "no version file in PlcLogic, check the enforce flag in mic7001_app/version.dat"
			if [ $enforce_new -eq 1 ]; then
				echo "need update new version"
				mv /userapp/PlcLogic /userapp/PlcLogic_backup
				mv /userapp/mic7001_app /userapp/PlcLogic
			fi
		else
			while read line; do
				name=`echo $line|awk -F '=' '{print $1}'`
				value=`echo $line|awk -F '=' '{print $2}'`
				case $name in
				"version")
					version_old=$value
					;;
				"enforce")
					enforce_old=$value
					;;
				*)
					;;
			esac
			done < /userapp/PlcLogic/version.dat
			
			#echo $version_old
			#echo $enforce_old
			
			if [ $version_new -gt $version_old ]  || [ $enforce_new -eq 1 ]; then
				echo "need update new version"
				mv /userapp/PlcLogic /userapp/PlcLogic_backup
				mv /userapp/mic7001_app /userapp/PlcLogic
			fi
		fi
	fi
fi

echo "update script finished."
